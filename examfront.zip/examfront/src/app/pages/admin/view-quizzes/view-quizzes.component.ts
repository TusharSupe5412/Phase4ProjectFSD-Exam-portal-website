import { Component, OnInit } from '@angular/core';
import { switchAll } from 'rxjs';
import { QuizService } from 'src/app/services/quiz.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-quizzes',
  templateUrl: './view-quizzes.component.html',
  styleUrls: ['./view-quizzes.component.css']
})
export class ViewQuizzesComponent implements OnInit {


  quizzes=[
    {
      qId:'23',
      title:'Basic java quiz',
      description:'The Java SE is a computing-based platform and used for developing desktop or Window based applications. Thus, core Java is the part of Java SE where the developers develop desktop-based applications by using the basic concepts of Java where JDK (Java Development Kit) is a quite familiar Java SE implementation.',
      maxMarks:'50',
      noOfQuestions:'20',
      active:'',
      category:{
        title:'Programming'
      }
     },
    {
      qId:'23',
      title:'Basic java quiz',
      description:'The Java SE is a computing-based platform and used for developing desktop or Window based applications. Thus, core Java is the part of Java SE where the developers develop desktop-based applications by using the basic concepts of Java where JDK (Java Development Kit) is a quite familiar Java SE implementation.',
      maxMarks:'50',
      noOfQuestions:'20',
      active:'',
      category:{
        title:'Programming'
      }
     },
  ];

  constructor(private _quiz:QuizService) { }

  ngOnInit(): void {

    this._quiz.quizzes().subscribe(
      (data:any)=>{
        this.quizzes=data;
        console.log(this.quizzes);
      },
      (error)=>{
        console.log(error);
        Swal.fire('Error !!', "Error in loading data from server",'error')
      }
    );
  }

  // delete quizz

  deleteQuiz(qId:any){

    Swal.fire({
      icon:'warning',
      title: "Are you sure ?",
      confirmButtonText:'Delete',
      showCancelButton:true,
    }).then((result)=>{

      if(result.isConfirmed)
      {
        // delete

        this._quiz.deleteQuiz(qId).subscribe(
          (data:any)=>{
           this.quizzes = this.quizzes.filter((quiz)=>quiz.qId!=qId)
            Swal.fire('Success','Quiz deleted successfully','success');
          },
          (error)=>{
            Swal.fire('Error !!','Error while deleting quiz','error')
          }
        );
      }
    })
  }

}
